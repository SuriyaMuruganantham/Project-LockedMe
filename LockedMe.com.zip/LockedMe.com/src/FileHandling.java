import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Scanner;

public class FileHandling {
	public static void Seefile()
	
	{
	
	File directorypath =new File("C:\\Users\\SundeepHarini\\Desktop\\java\\alpha");
    String files[]=directorypath.list();
    String temp;
   if(files.length==0)
   {
	   System.out.println("Empty folder");
   }
   else
   {
    for(int i=0;i<files.length;i++)
    	for(int j=i+1;j<files.length;j++)
    		if(files[i].compareTo(files[j])>0)
    		{
    			temp=files[i];
    			files[i]=files[j];
    			files[j]=temp;
    		}
    System.out.println("The files in alphabatical order");
    for(int i=0;i<files.length;i++)
    {
    	System.out.println(files[i]);
    }
   }
	
	}
public static void Createfile() 
{
try
{

	String Filename;
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the file name");
	Filename=br.readLine();
	
	File file = new File("C:\\Users\\SundeepHarini\\Desktop\\java\\"+ Filename + ".txt");
	
	if (file.createNewFile())
	{
		System.out.println("File created sucessfully"+" "+file.getName());
		System.out.println("If you want to write a content in a file 1.Yes or 2.No type 1or2");
		
		Scanner sc = new Scanner(System.in);
        int choice= sc.nextInt();
		
		if(choice==1)
		{
			
			System.out.println("Enter the text");
			Scanner t = new Scanner(System.in);
		    String text = t.nextLine();
		    FileWriter fwriter = null;
		    BufferedWriter writer=null;
		    try {
		    	fwriter=new FileWriter("C:\\Users\\SundeepHarini\\Desktop\\java\\"+Filename +".txt");
		    	writer = new BufferedWriter(fwriter);
		    	writer.write(text);
		    	writer.newLine();
		    	writer.close();
		    
		    System.out.println("Successfully worte to the file");
		    }
		    
		    catch(Exception e)
		    {
		}
		}
		else if(choice==2)
	     System.out.println("You have skipped the writing option");

	}
	
		else {
	    System.out.println("File already exists"+" "+file.getName());
	}
	
}

catch(Exception e)
{
	
}
}
public static void Deletefile() 
{
 try {  
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the file name to be deleted");
	String fname = sc.next();
	File file= new File("C:\\Users\\SundeepHarini\\Desktop\\java\\"+fname +".txt");
	if(file.delete())
	{
	System.out.println(file.getName()+" "+"File has been deleted sucessfully");	
		
 }
	else
	{
		System.out.println(file.getName()+" "+"Failed to delete the file enter the correct file name");
	}
	
 }
 catch(Exception e)
 {
	 System.out.println("Exception");
 }
}
public static void Searchfile()
{
	try {  
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the file name to be search");
		String fname = sc.nextLine();
		File file = new File("C:\\Users\\SundeepHarini\\Desktop\\java\\"+fname +".txt");
		if(file.exists())
		{
			System.out.println("File found"+" "+file.getName());
		}
		else
		{
			System.out.println("File not found"+" "+file.getName());
		}
		
		}	   
	   
		 	catch(Exception e)
	{
		System.out.println("exception");
	}
		
	
}
	}



























































import java.io.IOException;
import java.util.Scanner;

public class Main extends FileHandling {
	public static void main(String[] args) throws IOException
	{
		System.out.println("***************************************************************\n");
		System.out.println("***Welcome to LockedME***\n");
		System.out.println("Application was developed by Suriya\n");
		System.out.println("***************************************************************\n");
		System.out.println("Instructions:-");
		System.out.println("Please ensure that the correct filename is provided for searching or deleting the files\n");
		menu();
	}
		static void menu()
		{
			
			Scanner sc = new Scanner(System.in);
			int ch;
		while(true)
		{
			System.out.println("**Main Menu**\n");
			System.out.println("Choose the options to be performed\n");
			System.out.println("1.Retrieve all files inside the folder");
			System.out.println("2.File operations");
			System.out.println("3.Close the application");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				Seefile();
			break;
			case 2:
				System.out.println("**File operations**\n");
				int choice;
               
				while(true)
				{
					System.out.println("1.Create file");
					System.out.println("2.Deletefile");
					System.out.println("3.Search file");
					System.out.println("4.Go back to the main menu");	
					choice= sc.nextInt();
				
				if(choice==1)
				Createfile();
				else if(choice==2)
				Deletefile();
				else if(choice==3)
				Searchfile();
				else if(choice==4)
				menu();
				}
					
			
			case 3:
				System.out.println("****Thank you****");
				System.exit(0);
			}
		}
      	}
	
}
